
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class main {

    public static void main(String[] args) throws InterruptedException {

      Menu m = new Menu();
      m.start();
    }
}
